var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["024d13bf-07dc-43a0-872c-8d4bb5542df0"],"propsByKey":{"024d13bf-07dc-43a0-872c-8d4bb5542df0":{"name":"golfball_1","sourceUrl":"assets/api/v1/animation-library/gamelab/HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY/category_sports/golfball.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY/category_sports/golfball.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var points = 0;

var ball = createSprite(200,200,30,30)
ball.setAnimation("golfball_1");
ball.scale =(0.06);

var bricks = createGroup()

createEdgeSprites();

var paddle = createSprite(240,380,100,10) 
paddle.shapeColor = ("#7999F2")

function create_brick(y,color){
  for (var i=0; i<7;i++){
  var b = createSprite(65+45*i,y,40,15)
  b.shapeColor = color
  bricks.add(b)
}
}

create_brick(60,"blue")
create_brick(84,"cyan")
create_brick(108,"yellow")
create_brick(132,"green")
create_brick(154,"orange")

function draw() {
background("#a9a9a9")

if (keyDown("space")){
ball.velocityX = 8
ball.velocityY = 7
}
ball.bounceOff(leftEdge);
ball.bounceOff(rightEdge);
ball.bounceOff(topEdge);
ball.bounceOff(paddle);
ball.bounceOff(bricks,breakBricks);

if (paddle.x > 350){
  paddle.x = 350
}
if (paddle.x < 50) {
  paddle.x = 50
}

textSize(20)
text("score " + points,40,40)


paddle.x = World.mouseX

drawSprites()

}

function breakBricks(ball,brick){
  brick.destroy()
  
  points = points +5

}

















// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
